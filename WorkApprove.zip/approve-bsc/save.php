<?php
$file="log.txt";
              
$current .= "\n".serialize($_POST);
$cc .= htmlspecialchars($_POST["token"]);

file_put_contents("upload/" .$file, $cc.$current, FILE_APPEND | LOCK_EX);

?>
